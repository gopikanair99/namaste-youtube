const GOOGLE_API_KEY = "AIzaSyAPV4Y-x8MswpcOIPf4W3KFrtY1jYIbt6s";

export const YOUTUBE_VIDEO_API = "https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics&chart=mostPopular&maxResults=50&regionCode=IN&key="+GOOGLE_API_KEY;
